plugins {
    java
}

dependencies {
   implementation(project(":a"))
}
