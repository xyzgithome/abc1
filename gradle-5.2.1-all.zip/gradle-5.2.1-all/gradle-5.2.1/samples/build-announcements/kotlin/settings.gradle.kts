rootProject.name = "build-announcements"
