package cn.bugstack.guide.idea.plugin;

import cn.bugstack.guide.idea.plugin.ui.ReadUI;

public class Config {

    public static ReadUI readUI = null;

}
