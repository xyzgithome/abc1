plugins {
    id("java-library-convention")
}
