@Service
public class Service1 {

}