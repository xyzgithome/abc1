# Chapter 2 - Overview 

* LanguageType
* ComponentBinaries