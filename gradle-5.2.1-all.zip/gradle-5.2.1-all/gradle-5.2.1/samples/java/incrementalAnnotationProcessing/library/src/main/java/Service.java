/**
 * Marks a class for inclusion in a global service registry.
 */
public @interface Service {

}