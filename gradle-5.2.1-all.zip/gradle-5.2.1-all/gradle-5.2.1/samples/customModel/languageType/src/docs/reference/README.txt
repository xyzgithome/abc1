Some text docs.
