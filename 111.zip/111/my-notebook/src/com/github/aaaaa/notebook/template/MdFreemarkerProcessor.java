package com.github.aaaaa.notebook.template;

import com.intellij.ide.fileTemplates.impl.UrlUtil;
import freemarker.cache.StringTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class MdFreemarkerProcessor extends AbstractFreemarkerTplProcessor {
    @Override
    protected Object getModel(SrcNoteData noteData) {
        Map<String, Object> model = new HashMap<>();
        model.put("topic", noteData.getTopic());
        model.put("noteList", noteData.getNoteList());
        return model;
    }

    @Override
    protected Template getTemplate() throws IOException {
        Configuration configuration = new Configuration(Configuration.VERSION_2_3_31);

        String tplContent = UrlUtil.loadText(MdFreemarkerProcessor.class.getResource("/tpl/md.ftl"));
        StringTemplateLoader strTpl = new StringTemplateLoader();
        strTpl.putTemplate("mdTemplate", tplContent);
        configuration.setTemplateLoader(strTpl);
        return configuration.getTemplate("mdTemplate");
    }

    @Override
    protected Writer getWriter(SrcNoteData noteData) throws Exception {
        File file = new File(noteData.getFileName());
        return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8));
    }
}
