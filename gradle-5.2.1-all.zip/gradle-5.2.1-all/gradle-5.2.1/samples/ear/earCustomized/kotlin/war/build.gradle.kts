plugins {
    war
}

repositories {
    mavenCentral()
}

dependencies {
    implementation(group = "log4j", name = "log4j", version = "1.2.15", ext = "jar")
}
