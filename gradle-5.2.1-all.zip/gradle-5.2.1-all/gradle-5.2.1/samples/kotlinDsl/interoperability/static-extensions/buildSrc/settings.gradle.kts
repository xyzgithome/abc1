pluginManagement {
    repositories {
        gradlePluginPortal()
    }
}
