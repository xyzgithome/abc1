/**
 * Automatically creates a repository to store objects marked with this annotation.
 */
public @interface Entity {

}