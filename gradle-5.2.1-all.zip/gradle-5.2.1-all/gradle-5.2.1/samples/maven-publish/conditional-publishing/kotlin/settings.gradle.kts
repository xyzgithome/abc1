rootProject.name = "maven-conditional-publishing"
