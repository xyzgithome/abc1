rootProject.name = "configure-by-init-script"
