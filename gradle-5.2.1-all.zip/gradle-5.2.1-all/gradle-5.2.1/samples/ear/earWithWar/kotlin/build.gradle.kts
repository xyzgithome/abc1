// tag::use-ear-plugin[]
plugins {
    ear
}
// end::use-ear-plugin[]

repositories {
    mavenCentral()
}

dependencies {
    deploy(project(path = ":war", configuration = "archives"))

    earlib(group = "log4j", name = "log4j", version = "1.2.15", ext = "jar")
}
