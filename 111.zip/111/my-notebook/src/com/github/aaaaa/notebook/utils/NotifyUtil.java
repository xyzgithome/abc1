package com.github.aaaaa.notebook.utils;

import com.intellij.notification.Notification;
import com.intellij.notification.NotificationDisplayType;
import com.intellij.notification.NotificationGroup;
import com.intellij.notification.Notifications;
import com.intellij.openapi.ui.MessageType;

public class NotifyUtil {
    public static void optRetNotify(String displayId) {
        NotificationGroup notificationGroup = new NotificationGroup(displayId, NotificationDisplayType.BALLOON, false);
        Notification notification = notificationGroup.createNotification("操作成功", MessageType.INFO);
        Notifications.Bus.notify(notification);
    }
}
