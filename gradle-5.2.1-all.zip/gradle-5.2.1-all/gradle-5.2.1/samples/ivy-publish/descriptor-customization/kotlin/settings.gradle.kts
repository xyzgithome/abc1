rootProject.name = "descriptor-customization"
