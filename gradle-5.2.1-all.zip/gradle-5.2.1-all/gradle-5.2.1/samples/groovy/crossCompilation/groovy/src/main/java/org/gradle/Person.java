package org.gradle;

public interface Person {
    String getName();
}