rootProject.name = "maven-publish-multiple"
include("project1", "project2")
