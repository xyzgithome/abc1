package org.gradle.sample;

class bad_name {

}