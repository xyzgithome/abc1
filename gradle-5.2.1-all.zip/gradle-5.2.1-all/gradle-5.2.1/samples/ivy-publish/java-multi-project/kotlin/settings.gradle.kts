rootProject.name = "ivy-publish-java"
include("project1", "project2")
