rootProject.name = "adhoc"

includeBuild("../my-app")
includeBuild("../my-utils")
