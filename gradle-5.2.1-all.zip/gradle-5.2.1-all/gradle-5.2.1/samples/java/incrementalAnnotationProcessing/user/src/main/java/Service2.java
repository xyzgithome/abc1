@Service
public class Service2 {

}