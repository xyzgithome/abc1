rootProject.name = "precompiled-script-plugins-in-buildSrc"
