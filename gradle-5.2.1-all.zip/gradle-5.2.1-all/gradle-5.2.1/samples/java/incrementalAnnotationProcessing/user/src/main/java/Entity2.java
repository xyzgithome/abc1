@Entity
public class Entity2 {
}
