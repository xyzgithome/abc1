package com.github.aaaaa.notebook.template;

public interface TplProcessor {
    void process(SrcNoteData noteData) throws Exception;
}
