@Entity
public class Entity1 {
}
