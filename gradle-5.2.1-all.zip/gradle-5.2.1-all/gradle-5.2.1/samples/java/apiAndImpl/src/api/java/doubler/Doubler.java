package doubler;

public interface Doubler {
    int doubleIt(int toDouble);
}