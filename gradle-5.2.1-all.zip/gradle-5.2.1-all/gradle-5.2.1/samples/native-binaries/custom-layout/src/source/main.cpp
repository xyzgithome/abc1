extern "C" {
    #include "hello.h"
}

int main () {
  hello();
  return 0;
}
