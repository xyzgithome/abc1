// tag::apply[]
plugins {
    `kotlin-dsl`
}
// end::apply[]

repositories {
    jcenter()
}
