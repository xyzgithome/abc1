// tag::configure-build-src-build-cache[]
apply(from = File(settingsDir, "gradle/buildCacheSettings.gradle.kts"))
// end::configure-build-src-build-cache[]
