package myKotlin

class TheTargetType

fun TheTargetType.kotlinExtensionFunction(s: String, i: Int, a: Any) {
}
