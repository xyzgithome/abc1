package com.acme;

interface HeatSensor {
    double getTemperature();
}
