// tag::android[]
plugins {
    id("com.android.library")
}

android {
    // ...
// end::android[]
    compileSdkVersion(27)
// tag::android[]
}
// end::android[]
