#include <stdio.h>
#include "sum.h"

int main () {
  int x = sum(5, 7);
  printf("5 + 7 = %d\n", x);
  return 0;
}
