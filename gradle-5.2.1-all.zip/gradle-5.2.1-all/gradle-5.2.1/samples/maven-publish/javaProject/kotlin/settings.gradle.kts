rootProject.name = "javaProject"
