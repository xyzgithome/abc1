rootProject.name = "applying-the-kotlin-dsl-plugin"
