package cn.bugstack.guide.idea.plugin.domain.model.vo;

public class Stock {

    private Data data;
    private GoPicture goPicture;

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public GoPicture getGoPicture() {
        return goPicture;
    }

    public void setGoPicture(GoPicture goPicture) {
        this.goPicture = goPicture;
    }
}
