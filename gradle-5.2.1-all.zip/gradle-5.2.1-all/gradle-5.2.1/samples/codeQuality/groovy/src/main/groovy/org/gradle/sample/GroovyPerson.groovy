package org.gradle.sample

class GroovyPerson {
    def String name
}