package cn.bugstack.guide.idea.plugin.test;

public class ApiTest {

    public static void main(String[] args) {

    }

}
