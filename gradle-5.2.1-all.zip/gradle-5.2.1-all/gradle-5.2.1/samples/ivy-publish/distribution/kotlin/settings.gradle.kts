rootProject.name = "distribution"
