#include "hello.h"

int main () {
    Greeter greeter;
    greeter.hello();
    return 0;
}
