rootProject {
    apply(plugin = "build-announcements")
}
