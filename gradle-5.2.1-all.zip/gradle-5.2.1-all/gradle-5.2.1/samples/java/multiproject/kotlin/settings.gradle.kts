rootProject.name = "multiproject"

// tag::include-projects[]
include("shared", "api", "services:webservice", "services:shared")
// end::include-projects[]
