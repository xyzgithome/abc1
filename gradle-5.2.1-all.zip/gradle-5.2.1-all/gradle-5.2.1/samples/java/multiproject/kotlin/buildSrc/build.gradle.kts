repositories {
    mavenCentral()
}

dependencies {
    testImplementation("junit:junit:4.12")
}
