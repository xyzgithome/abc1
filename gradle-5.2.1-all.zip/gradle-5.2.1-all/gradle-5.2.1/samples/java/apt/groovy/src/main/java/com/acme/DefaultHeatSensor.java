package com.acme;

public class DefaultHeatSensor implements HeatSensor {
    public double getTemperature() {
        return 20d;
    }
}
