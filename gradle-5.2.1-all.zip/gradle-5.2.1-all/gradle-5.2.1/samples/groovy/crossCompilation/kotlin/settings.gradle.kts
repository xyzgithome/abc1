rootProject.name = "cross-compilation"
