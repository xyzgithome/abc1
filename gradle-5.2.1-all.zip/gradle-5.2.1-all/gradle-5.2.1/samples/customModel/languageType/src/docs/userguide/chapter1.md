# Chapter 1 - Intoduction

## Hello World

This is a "hello world" example:

    task hello {
        doLast {
            println 'Hello World!'
        }
    }
