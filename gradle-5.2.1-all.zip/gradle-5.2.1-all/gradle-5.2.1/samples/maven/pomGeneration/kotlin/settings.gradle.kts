rootProject.name = "pomGeneration"
