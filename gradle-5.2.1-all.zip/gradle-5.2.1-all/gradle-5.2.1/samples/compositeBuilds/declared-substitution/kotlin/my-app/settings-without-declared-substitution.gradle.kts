rootProject.name = "app"

includeBuild("../anonymous-library")
