rootProject.name = "code-quality"
