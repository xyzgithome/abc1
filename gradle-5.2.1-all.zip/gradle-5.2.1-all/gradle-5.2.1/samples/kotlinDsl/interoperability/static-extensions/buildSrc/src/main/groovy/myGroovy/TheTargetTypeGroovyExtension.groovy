package myGroovy

class TheTargetType {}

class TheTargetTypeGroovyExtension {
    static void groovyExtensionMethod(TheTargetType self, String s, int i, Object o) {}
}
