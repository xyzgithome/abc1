dependencies {
    implementation(project(":shared"))
}
