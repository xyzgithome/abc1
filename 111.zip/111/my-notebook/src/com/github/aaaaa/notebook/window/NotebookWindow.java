package com.github.aaaaa.notebook.window;

import com.github.aaaaa.notebook.data.Global;
import com.github.aaaaa.notebook.template.DefaultSrcNoteData;
import com.github.aaaaa.notebook.template.MdFreemarkerProcessor;
import com.github.aaaaa.notebook.template.TplProcessor;
import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptorFactory;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.ui.Messages;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.wm.ToolWindow;
import lombok.extern.slf4j.Slf4j;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

@Slf4j
public class NotebookWindow {
    private JTextField noteTitle;
    private JTable noteContentList;
    private JButton btnCreateDoc;
    private JButton btnClear;
    private JButton btnClose;
    private JPanel contentPanel;

    private void init() {
        noteContentList.setModel(Global.DEFAULT_TABLE);
        noteContentList.setEnabled(true);
    }


    public NotebookWindow(Project project, ToolWindow toolWindow) {
        init();
        btnClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Global.reset();
            }
        });
        btnClose.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toolWindow.hide(null);
            }
        });
        btnCreateDoc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println(noteTitle.getText());
                String topic = noteTitle.getText();
                String filename = topic+".md";
                if (topic == null || topic.trim().length() == 0) {
//                    MessageDialogBuilder.yesNo("操作结果", "文档标题不存在");

                    Messages.showMessageDialog("文档标题为空","生成笔记", Messages.getErrorIcon());
                    return;
                }
                VirtualFile virtualFile = FileChooser.chooseFile(FileChooserDescriptorFactory.createSingleFolderDescriptor(), project, project.getBaseDir());
                if (virtualFile != null) {
                    String path = virtualFile.getPath();
                    String fullPath = path + "/" + filename;
                    TplProcessor mdFreemarkerProcessor = new MdFreemarkerProcessor();
                    try {
                        mdFreemarkerProcessor.process(new DefaultSrcNoteData(fullPath, topic, Global.NOTE_LIST));
                        Messages.showMessageDialog("success!!!","生成笔记", Messages.getInformationIcon());
                    } catch (Exception exception) {
                        Messages.showMessageDialog("fail!!!","生成笔记", Messages.getErrorIcon());
                        log.error("generate md document fail, msg={}", exception.getMessage());
                    }
                }
            }
        });
    }

    public JPanel getContentPanel() {
        return contentPanel;
    }
}
