rootProject.name = "my-utils"

include("number-utils", "string-utils")
