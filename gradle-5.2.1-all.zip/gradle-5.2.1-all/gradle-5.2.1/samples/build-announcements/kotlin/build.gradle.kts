// tag::use-plugin[]
plugins {
    `build-announcements`
}
// end::use-plugin[]
