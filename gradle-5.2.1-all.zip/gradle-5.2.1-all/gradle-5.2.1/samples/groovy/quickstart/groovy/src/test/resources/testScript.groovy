println "this is a script"
